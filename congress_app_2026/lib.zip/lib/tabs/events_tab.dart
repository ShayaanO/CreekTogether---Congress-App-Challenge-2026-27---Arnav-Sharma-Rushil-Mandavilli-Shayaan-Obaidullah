import 'package:flutter/material.dart';

import '../widgets/web_view_tab.dart';

class EventsTab extends StatelessWidget {
  const EventsTab({super.key});

  static const url = 'https://calendar.google.com/calendar/u/0/embed?ctz=America/Denver&src=c_2255cc795fbd2afb797ab6faaedc509f21396e899ec9c16bf825a72ad48dc4ab@group.calendar.google.com';

  @override
  Widget build(BuildContext context) {
    return const WebViewTab(url: url);
  }
}